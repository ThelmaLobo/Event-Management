
class Customer
{
    private String name;   
    private String passwd;
    private String emailAddress;
    private String phoneNumber;
    
    public Customer()
    {
        name = "";
        passwd = "";
        emailAddress = "";
        phoneNumber = "";
    }
    public Customer(String newName, String newPasswd, String newEmail, String newPhoneNumber)
    {
        name = newName;
        passwd = newPasswd;
        emailAddress = newEmail;
        phoneNumber = newPhoneNumber;
    }
    public void setName(String newName)
    {
        name = newName;
    }
    public String getName()
    {
        return name;
    }
    public void setPasswd(String newPasswd)
    {
        passwd = newPasswd;
    }
    public String getPasswd()
    {
        return passwd;
    }
    public void setEmailAddress(String newEmail)
    {
        emailAddress = newEmail;
    }
    public String getEmailAddress()
    {
        return emailAddress;
    }
    public void setPhone(String newPhone)
    {
        phoneNumber = newPhone;
    }
    public String phoneNumber()
    {
        return phoneNumber;
    }
    public String displayCustomer()
    {
        System.out.println("Customer Name: " + name);
        System.out.println("Email Address: " + emailAddress);
        System.out.println("Password: " + passwd);
        System.out.println("Phone Number: " + phoneNumber);
        return ("Customer Name: " + name + "Email Address: " + emailAddress + "Password: " + passwd + "Phone Number: " + phoneNumber);
    }
    public String toString()    
    {
        return ("Customer Name: " + name + "Email Address: " + emailAddress + "Password: " + passwd + "Phone Number: " + phoneNumber);
    }
}
