import java.util.*;
import java.io.*;

public class ListOfCustomers
{
    private ArrayList<Customer> customers;
    
    public ListOfCustomers()
    {
        this.customers = new ArrayList<Customer>();
    }
    public ListOfCustomers(ArrayList<Customer> newCustomer)
    {
        this.customers = newCustomer;
    }
    
    public void setCustomers(ArrayList<Customer> newCustomer)
    {
        this.customers = newCustomer;
    }
    
    /**
     * Return arraylist
     */
    public ArrayList<Customer> getCustomers()
    {
        return customers;
    }
    
    public void addCustomers(String newName,String newPasswd, String newEmail, String newPhoneNumber)
    {
        Customer newCustomer = new Customer(newName, newPasswd, newEmail, newPhoneNumber);
        customers.add(newCustomer);
    }
        
    public int getNumberOfCustomers()
    {
        return customers.size();
    }
    
    public void listAllCustomers()
    {
        for(int i = 0;  i < customers.size(); i++)
        {
            System.out.println(customers.get(i));
        }
    }
    
    public Customer getCustomer(int index)
    {
        return customers.get(index);
    }
    
}
