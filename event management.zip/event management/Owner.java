
public class Owner
{
    private String ownerName;
    private String passwd;
    private String emailAddress;
    private String phoneNumber;
    private String address;
 
    public Owner()
    {
        ownerName = "";
        passwd = "";
        emailAddress = "";
        phoneNumber = "";
        address = "";     
    }
    
    public Owner(String newName,String newPasswd, String newEmail, String newPhoneNumber, String newAddress)
    {
        ownerName = newName;
        passwd = newPasswd;
        emailAddress = newEmail;
        phoneNumber = newPhoneNumber;
        address = newAddress;
    }
    public void setName(String newName)
    {
        ownerName = newName;
    }
    public String getName()
    {
        return ownerName;
    }
    public void setPasswd(String newPasswd)
    {
        passwd = newPasswd;
    }
    public String getPasswd()
    {
        return passwd;
    }
    public void setEmailAddress(String newEmail)
    {
        emailAddress = newEmail;
    }
    public String getEmailAddress()
    {
        return emailAddress;
    }
    public void setPhoneNumber(String newPhoneNumber)
    {
        phoneNumber = newPhoneNumber;
    }
    public String getPhoneNumber()
    {
        return phoneNumber;
    }
    public void setAddress(String newAddress)
    {
        address = newAddress;
    }
    public String getAddress()
    {
        return address;
    }
    public String displayOwner()
    {
        System.out.println("Owner Name: " + ownerName);
        System.out.println("Password: " + passwd);
        System.out.println("Email Address: " + emailAddress);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Address: " + address);
        return ("Owner Name: " + ownerName + "Password: " + passwd + "Email Address: " + emailAddress +
                    "Phone Number: " + phoneNumber + "Address: " + address);
    }
    public String toString()
    {
        return ("Owner Name: " + ownerName + "Password: " + passwd + "Email Address: " + emailAddress +
                    "Phone Number: " + phoneNumber + "Address: " + address);
    }
}
