import java.util.*;
import java.io.*;

public class FileIO
{
    private String filename;

    /**
     * Constructor for objects of class FileIO
     */
    public FileIO()
    {
        filename = "";
    }
    
    /**
     * Constructor for objects of class FileIO
     */
    public FileIO(String newFilename)
    {
        filename = newFilename;
    }
    
    public String getFilename()
    {
        return filename;
    }
    
    public void setFilename(String newFilename)
    {
        filename = newFilename;
    }
    
    public ArrayList<String> readFileArray(String newFilename)
    {
        ArrayList<String> listLine = new ArrayList<String>();
        String line = null;
        try 
        {
            FileReader inputFile = new FileReader(newFilename);
            Scanner read = new Scanner(inputFile);
            while(read.hasNextLine())
            {
                line = read.nextLine();
                listLine.add(line);
            }
        }catch(FileNotFoundException e)
        {
            System.out.println("File not exist!");
        }
        return listLine;
    }
    
    public void writeFile(String contents,String fileName)
    {
        boolean test = true;
        
        try
        {    
            File file = new File(fileName);
            FileWriter outputFile = new FileWriter(file, true);
            BufferedWriter output = new BufferedWriter(outputFile);
            PrintWriter outputpr = new PrintWriter(output);
            while(test)
            {
                if(file.length() != 0)
                {
                    outputpr.println();
                    outputpr.write(contents);
                    break;
                }
                else
                {
                    outputpr.write(contents);
                    break;
                }
            }
            outputpr.close();
            output.close();
            outputFile.close();
            test = false;
        }
        catch(Exception e)
        {
            System.out.println("File not exist!");
            test = true;
        }
    }
    
    public String readFile(String fileName)
    {
        String line = null;
        File file = new File(fileName);
        try
        {
            Scanner scaninput = new Scanner(file);
            line = scaninput.nextLine();
        }
        catch (FileNotFoundException e)
        {
            System.out.println("File is not found!");
        }
        return line;
    }
    
    public void removeSomethingFromFile(String inputFile, String deleteItem)
    {
        try
        {
            String inputFilename = inputFile;
            String outputFilename = ("tempFile.txt");
            String lineToRemove = deleteItem;
 
            File inpFile = new File(inputFilename);            
            FileWriter outpFile = new FileWriter(outputFilename, true);
            Scanner read = new Scanner(inputFile);
            BufferedWriter output = new BufferedWriter(outpFile);
            PrintWriter outputpr = new PrintWriter(output);        
            String line = read.nextLine();
            
            while(read.hasNextLine())
            {               
                if (!read.equals(lineToRemove)) 
                {
                    outputpr.write(line);
                    outputpr.println();                    
                }                
                else
                {
                    System.out.println("Nothing removed");
                }
            }
            outputpr.close();
            outputpr = null;
            output.close();
            output = null;
            read.close();
            read = null;
            
            if(deleteFile(inputFile))
            {
                File f1 = new File(outputFilename);
                f1.setWritable(true);
                File f2 = new File(inputFile);
                f2.setWritable(true);
                boolean check = f1.renameTo(f2); 
                System.out.println(check +"rename");
            }
        } 
        catch (Exception e) 
        {
            System.out.println("There is some error occured");
        }
    }   
    
    public boolean deleteFile(String inputFile)
    {
        File file = new File(inputFile);
        boolean delete = true;
        try
        {
            file.delete();        
            delete = true;
        }
        
        catch(Exception e)
        {
            System.out.println(inputFile + " file doesn't exist");
            delete = false;
        }
        return delete;
    }
}
