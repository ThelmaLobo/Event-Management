    
public class Discount
{
    private String discountName;
    private String discountType;
    private String description;
    private int discountMonth;
    
    public Discount()
    {
        discountName = "";
        discountType = "";
        description = "";
        discountMonth = 0;
    }
    
    public Discount(String newDiscountName,String newDiscountType,String newDescription,int newDiscountMonth)
    {
        discountName = newDiscountName;
        discountType = newDiscountType;
        description = newDescription;
        discountMonth = newDiscountMonth;
    }

    public void setDiscountName(String newDiscountName)
    {
        discountName = newDiscountName;
    }
    
    public String getDiscountName()
    {
        return discountName;
    }
    public void setDiscountType(String newDiscountType)
    {
        discountType = newDiscountType;
    }
    public String getDiscountType()
    {
        return discountType;
    }
    public void setDescription(String newDescription)
    {
        description = newDescription;
    }
    public String getDescription()
    {
        return description;
    }
    public void setDiscountMonth(int newDiscountMonth)
    {
        discountMonth = newDiscountMonth;
    }
    public int getDiscountMonth()
    {
        return discountMonth;
    }
    
    public String displayDiscount()
    {
        System.out.println("Discount Name: " + discountName);
        System.out.println("Discount Type: " + discountType);
        System.out.println("Description: " + description);
        System.out.println("Discount Period: " + discountMonth + " months");
        return ("Discount Name: " + discountName +"Discount Type: " + discountType +"Description: " + description+"Discount Period: " + discountMonth+ " months");
    }
    public String toString()
    {
        return ("Discount Name: " + discountName +"Discount Type: " + discountName+"Description: " + discountName+"Discount Period: " + discountName + " months");
    }
}
