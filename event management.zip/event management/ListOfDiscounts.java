import java.util.*;
import java.io.*;

public class ListOfDiscounts
{
    private ArrayList<Discount> discounts;
    
    public ListOfDiscounts()
    {
        this.discounts = new ArrayList<Discount>();
    }
    public ListOfDiscounts(ArrayList<Discount> newDiscount)
    {
        this.discounts = newDiscount;
    }
    
    public void setDiscounts(ArrayList<Discount> newDiscount)
    {
        this.discounts = newDiscount;
    }
    
    /**
     * Return arraylist
     */
    public ArrayList<Discount> getDiscounts()
    {
        return discounts;
    }
    
    public void addDiscounts(String newDiscountName,String newDiscountType,String newDescription,int newDiscountMonth)
    {
        Discount newDiscount = new Discount(newDiscountName, newDiscountType,newDescription, newDiscountMonth);
        discounts.add(newDiscount);
    }
        
    public int getNumberOfDiscounts()
    {
        return discounts.size();
    }
    
    public void listAllDiscounts()
    {
        for(int i = 0;  i < discounts.size(); i++)
        {
            System.out.println(discounts.get(i));
        }
    }
    
    public Discount getDiscount(int index)
    {
        return discounts.get(index);
    }
    
    public int getDiscountIndex(int index)
    {
        return index;
    }
}
