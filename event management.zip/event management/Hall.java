
public class Hall
{
    private String hallName;
    private String hallAddress;
    private String hallDescription;
    private boolean hallAvailability;
    private String typeOfEvent;
    private int sizeOfHall;
    private boolean cateringAvailability;
    private boolean decorationAvailability;
    private String contactDetail;
    private String contactName;
    
    public Hall()
    {
        hallName = "";
        hallAddress = "";
        hallDescription = "";
        hallAvailability = true;
        typeOfEvent = "";
        sizeOfHall = 0;
        cateringAvailability = true;
        decorationAvailability = true;
        contactDetail = "";
        contactName = "";
    }
    public Hall(String newHallName,String newHallAddress, String newHallDescription, boolean newHallAvailability, 
                String newTypeOfEvent,int newSizeOfHall, boolean newCateringAvailability,boolean newDecorationAvailability,
                String newContactDetail, String newContactName)
    {
        hallName = newHallName;
        hallAddress = newHallAddress;
        hallDescription = newHallDescription;
        hallAvailability = newHallAvailability;
        typeOfEvent = newTypeOfEvent;
        sizeOfHall = newSizeOfHall;
        cateringAvailability = newCateringAvailability;
        decorationAvailability = newDecorationAvailability;
        contactDetail = newContactDetail;
        contactName = newContactName;
    }
    public void setHallName(String newHallName)
    {
        hallName = newHallName;
    }
    public String getHallName()
    {
        return hallName;
    }
    public void setHallAddress(String newHallAddress)
    {
        hallAddress = newHallAddress;
    }
    public String getHallAddress()
    {
        return hallAddress;
    }
    public void setHallDescription(String newHallDescription)
    {
        hallDescription = newHallDescription;
    }
    public String getHallDescription()
    {
        return hallDescription;
    }
    public void setHallAvailability(boolean newHallAvailability)
    {
        hallAvailability = newHallAvailability;
    }
    public boolean getHallAvailability()
    {
        return hallAvailability;
    }
    public void setTypeOfEvent(String newTypeOfEvent)
    {
        typeOfEvent = newTypeOfEvent;
    }
    public String getTypeOfEvent()
    {
        return typeOfEvent;
    }
    public void setSizeOfHall(int newSizeOfHall)
    {
        sizeOfHall = newSizeOfHall;
    }
    public int getSizeOfHall()
    {
        return sizeOfHall;
    }
    public void setCateringAvailability(boolean newCateringAvailability)
    {
        cateringAvailability = newCateringAvailability;
    }
    public boolean getCateringAvailability()
    {
        return cateringAvailability;
    }
    public void setDecorationAvailability(boolean newDecorationAvailability)
    {
        decorationAvailability =newDecorationAvailability;
    }
    public boolean getDecorationAvailability()
    {
        return decorationAvailability;
    }
    public void setContactDetail(String newContactDetail)
    {
        contactDetail = newContactDetail;
    }
    public String getContactDetail()
    {
        return contactDetail;
    }
    public void setContactName(String newContactName)
    {
        contactName = newContactName;
    }
    public String getContactName()
    {
        return contactName;
    }
    public String displayHall()
    {
        System.out.println("Hall Name: " + hallName);
        System.out.println("Hall Description: " + hallDescription);
        System.out.println("Hall Availability: " + hallAvailability);
        System.out.println("Hall Type Of Event: " + typeOfEvent);
        System.out.println("Hall Size: " + sizeOfHall);
        System.out.println("Hall Address: " + hallAddress);
        System.out.println("Catering Availability: " + cateringAvailability);
        System.out.println("Decoration Availability: " + decorationAvailability);
        System.out.println("Contact Detail: " + contactDetail);
        System.out.println("Contact Name: " + contactName);
        return ("Hall Name: " + hallName + "Hall Description: " + hallDescription+"Hall Availability: " + hallAvailability+ 
                    "Hall Type Of Event: " + typeOfEvent +"Hall Size: " + sizeOfHall+ "Hall Address: " + hallAddress + "Catering Availability: " + cateringAvailability
                    + "Decoration Availability: " + decorationAvailability + "Contact Detail: " + contactDetail
                    + "Contact Name: " + contactName);
    }
    public String toString()
    {
        return ("Hall Name: " + hallName + "Hall Description: " + hallDescription+"Hall Availability: " + hallAvailability+ 
                    "Hall Type Of Event: " + typeOfEvent +"Hall Size: " + sizeOfHall+ "Hall Address: " + hallAddress + "Catering Availability: " + cateringAvailability
                    + "Decoration Availability: " + decorationAvailability + "Contact Detail: " + contactDetail
                    + "Contact Name: " + contactName);
    }
    
}
