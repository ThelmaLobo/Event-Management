import java.util.*;
import java.io.*;

public class ListOfHalls
{
    private ArrayList<Hall> halls;
    public ListOfHalls()
    {
        this.halls = new ArrayList<Hall>();
    }
    public ListOfHalls(ArrayList<Hall> newHall)
    {
        this.halls = newHall;
    }
    public void setHalls(ArrayList<Hall> newHall)
    {
        this.halls = newHall;
    }
    public ArrayList<Hall> getHalls()
    {
        return halls;
    }
    
    public void addHalls(String newHallName,String newHallAddress, String newHallDescription, boolean newHallAvailability, 
                String newTypeOfEvent,int newSizeOfHall, boolean newCateringAvailability,boolean newDecorationAvailability,
                String newContactDetail, String newContactName)
    {
        Hall newHall = new Hall(newHallName,newHallAddress,newHallDescription,newHallAvailability, 
                        newTypeOfEvent,newSizeOfHall,newCateringAvailability,newDecorationAvailability,
                        newContactDetail, newContactName);
        halls.add(newHall);
    }
        
    public int getNumberOfHalls()
    {
        return halls.size();
    }
    
    public void listAllHalls()
    {
        for(int i = 0;  i < halls.size(); i++)
        {
            System.out.println(halls.get(i));
        }
    }
    
    public Hall getHall(int index)
    {
        return halls.get(index);
    }
}
