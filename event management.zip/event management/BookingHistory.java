
public class BookingHistory
{
    private String bookingNumber;
    private String bookingDate;
    private int totalBookingHours;
    private String bookingStartTime;
    private String bookingHallName;
    private String bookingLocation;
    private int bookingPayment;
    public BookingHistory()
    {
        bookingNumber= "";
        bookingDate ="";
        totalBookingHours=0;
        bookingStartTime="";
        bookingHallName="";
        bookingLocation="";
        bookingPayment=0;
    }
    public BookingHistory(String newBookingNumber,String newBookingDate,int newTotalBookingHours,String 
                        newBookingStartTime,String newBookingHallName,String newBookingLocation,
                        int newBookingPayment) 
    {
        bookingNumber = newBookingNumber;
        bookingDate = newBookingDate;
        totalBookingHours = newTotalBookingHours;
        bookingStartTime = newBookingStartTime;
        bookingHallName = newBookingHallName;
        bookingLocation = newBookingLocation;
        bookingPayment = newBookingPayment;
    }
    public void setBookingNumber(String newBookingNumber)
    {
        bookingNumber = newBookingNumber;
    }
    public String getBookingNumber()
    {
        return bookingNumber;
    }
    public void setBookingDate(String newBookingDate)
    {
        bookingDate = newBookingDate;
    }
    public String getBookingDate()
    {
        return bookingDate;
    }
    public void setTotalBookingHours(int newTotalBookingHours)
    {
        totalBookingHours = newTotalBookingHours;
    }
    public int getTotalBookingHours()
    {
        return totalBookingHours;
    }
    public void setBookingStartTime(String newBookingStartTime)
    {
        bookingStartTime = newBookingStartTime;
    }
    public String getBookingStartTime()
    {
        return bookingStartTime;
    }
    public void setBookingHallName(String newBookingHallName)
    {
        bookingHallName = newBookingHallName;
    }
    public String getBookingHallName()
    {
        return bookingHallName;
    }
    public void setBookingLocation(String newBookingLocation)
    {
        bookingLocation = newBookingLocation;
    }
    public String getBookingLocation()
    {
        return bookingLocation;
    }
    public void setBookingPayment(int newBookingPayment)
    {
        bookingPayment = newBookingPayment;
    }
    public int getBookingPayment()
    {
        return bookingPayment;
    }
    public String displayBookingHistory()
    {
        System.out.println("Booking Number: " + bookingNumber);
        System.out.println("Booking Date: " + bookingDate);
        System.out.println("Total Booking Hours: " + totalBookingHours);
        System.out.println("Booking Start Time: " + bookingStartTime);
        System.out.println("Booking Hall Name: " + bookingHallName);
        System.out.println("Booking Location: " + bookingLocation);
        System.out.println("Booking Payment: " + bookingPayment);
        return ("Booking Number: " + bookingNumber + "Booking Date: " + bookingDate + "Total Booking Hours: " + totalBookingHours +
                "Booking Start Time: " + bookingStartTime +"Booking Hall Name: " + bookingHallName+
                "Booking Location: " + bookingLocation +"Booking Payment: " + bookingPayment);
    }
    public String toString()
    {
        return ("Booking Number: " + bookingNumber + "Booking Date: " + bookingDate + "Total Booking Hours: " + totalBookingHours +
                "Booking Start Time: " + bookingStartTime +"Booking Hall Name: " + bookingHallName+
                "Booking Location: " + bookingLocation +"Booking Payment: " + bookingPayment);
    }




}
