
public class Quotation
{
    private String quoteTypeofEvent;
    private int quoteSizeOfHall;
    private boolean quoteCateringAvailability;
    private boolean quoteDecorationAvailability;
    private int quoteTotalBudget;
    private int quoteEstimatedGuest;
    
    
    
    /**
     * Constructor for objects of class Quotation
     */
    public Quotation()
    {
        quoteTypeofEvent="";
        quoteSizeOfHall=0;
        quoteCateringAvailability=true;
        quoteDecorationAvailability=true;
        quoteTotalBudget=0;
        quoteEstimatedGuest=0;
    }
    public Quotation(String newQuoteTypeofEvent,int newQuoteSizeOfHall, boolean newQuoteCateringAvailability,
                       boolean newQuoteDecorationAvailability,int newQuoteTotalBudget, int newQuoteEstimatedGuest)
    {
        quoteTypeofEvent=newQuoteTypeofEvent;
        quoteSizeOfHall=newQuoteSizeOfHall;
        quoteCateringAvailability=newQuoteCateringAvailability;
        quoteDecorationAvailability=newQuoteDecorationAvailability;
        quoteTotalBudget=newQuoteTotalBudget;
        quoteEstimatedGuest=newQuoteEstimatedGuest;
    }
    public void setQuoteTypeOfEvent(String newQuoteTypeOfEvent)
    {
        quoteTypeofEvent=newQuoteTypeOfEvent;
    }
    public String getQuoteTypeOfEvent()
    {
        return quoteTypeofEvent;
    }
    public void setQuoteSizeOfHall(int newQuoteSizeOfHall)
    {
        quoteSizeOfHall=newQuoteSizeOfHall;
    }
    public int getQuoteSizeOfHall()
    {
        return quoteSizeOfHall;
    }
    public void setQuoteCateringAvailability(boolean newQuoteCateringAvailability)
    {
        quoteCateringAvailability=newQuoteCateringAvailability;
    }
    public boolean getQuoteCateringAvailability()
    {
        return quoteCateringAvailability;
    }
    public void setQuoteDecorationAvailability(boolean newQuoteDecorationAvailability)
    {
        quoteDecorationAvailability=newQuoteDecorationAvailability;
    }
    public boolean getQuoteDecorationAvailability()
    {
        return quoteDecorationAvailability;
    }
    public void setQuoteTotalBudget(int newQuoteTotalBudget)
    {
        quoteTotalBudget=newQuoteTotalBudget;
    }
    public int getQuoteTotalBudget()
    {
        return quoteTotalBudget;
    }
    public void setQuoteEstimatedGuest(int newQuoteEstimatedGuest)
    {
        quoteEstimatedGuest=newQuoteEstimatedGuest;
    }
    public int getQuoteEstimatedGuest()
    {
        return quoteEstimatedGuest;
    }
    public String displayQuotation()
    {
        System.out.println("Quote Type Of Event: " + getQuoteTypeOfEvent());
        System.out.println("Quote Size Of Hall: " + getQuoteSizeOfHall());
        System.out.println("Quote Catering Availability: " + getQuoteCateringAvailability());
        System.out.println("Quote Decoration Availability: " + getQuoteDecorationAvailability());
        System.out.println("Quote Total Budget: " + getQuoteTotalBudget());
        return ("Quote Type Of Event: " + getQuoteTypeOfEvent()+
                "Quote Size Of Hall: " + getQuoteSizeOfHall()+
                "Quote Catering Availability: " + getQuoteCateringAvailability()+
                "Quote Decoration Availability: " + getQuoteDecorationAvailability()+
                "Quote Total Budget: " + getQuoteTotalBudget());
    }
    public String toString()
    {
        return ("Quote Type Of Event: " + getQuoteTypeOfEvent()+
                "Quote Size Of Hall: " + getQuoteSizeOfHall()+
                "Quote Catering Availability: " + getQuoteCateringAvailability()+
                "Quote Decoration Availability: " + getQuoteDecorationAvailability()+
                "Quote Total Budget: " + getQuoteTotalBudget());
    }
    


}
