import java.util.*;
import java.io.*;
import java.util.regex.Pattern;

public class PrimeEventSystem
{
    private ListOfHalls halls;
    private ListOfOwners owners;
    private ListOfCustomers customers;
    private ListOfDiscounts discounts;
    private ListOfQuotations quotations;
    public PrimeEventSystem()
    {
        halls = new ListOfHalls();
        owners = new ListOfOwners();
        customers = new ListOfCustomers();
        discounts = new ListOfDiscounts();
        quotations = new ListOfQuotations();
    }

    public void main()
    {
        Input input = new Input();
        int option = 0;

        while(option == 0)
        {
            menu();
            readHallFile();
            Scanner console = new Scanner (System.in);
            int choice = input.acceptIntegerInput();
            switch(choice)
            {
                case 1:
                if(adminLogin() == true)
                {
                    console.nextLine();
                    adminMenu();
                    int userOption = input.acceptIntegerInput();

                    switch(userOption)
                    {
                        case 1:

                        break;

                        case 2:
                        deleteDiscount("admindiscount.txt", "Prime Event");
                        break;

                        case 3:
                        System.out.println("There is no discount list.");
                        break;

                        case 4:
                        readDiscountFile("admindiscount.txt", "Prime Event");
                        break;

                        case 5:
                        System.out.println("There is no users list.");
                        break;

                        case 6:
                        System.out.println("There is no reviews list.");
                        break;

                        case 7:
                        readHallFile();
                        break;

                        case 8:
                        System.out.println("There is no reviews list.");
                        break;

                        case 9:
                        option=0;
                        break;

                        case 10:
                        System.exit(0);
                        break;

                    }
                    break;
                }

                case 2:        
                if(customerLogin() == true)
                {
                    console.nextLine();
                    customerMenu();
                    int userOption = input.acceptIntegerInput();

                    switch(userOption)
                    {
                        case 1:
                        readHallFile();
                        break;

                        case 2:
                        searchHall();
                        break;

                        case 3:
                        requestQuotation();
                        break;

                        case 4:
                        quotationList();
                        break;

                        case 5:
                        readDiscountFile("admindiscount.txt", "Prime Event");
                        readDiscountFile("ownerdiscount.txt","Owner");
                        break;

                        case 6:
                        System.out.println("No booking history!");
                        break;

                        case 7:
                        System.out.println("There is no previous booking!");
                        break;

                        case 8:
                        System.out.println("There is no review list!");
                        break;

                        case 9:
                        option = 0;
                        break;

                        case 10:
                        System.exit(0);
                        break;
                    }
                    break;
                }

                case 3:        
                if(ownerLogin() == true)
                {
                    console.nextLine();
                    ownerMenu();
                    int userOption = input.acceptIntegerInput();

                    switch(userOption)
                    {
                        case 1:
                        createHall();
                        break;

                        case 2:
                        updateHall();
                        break;

                        case 3:
                        deleteHall();
                        break;

                        case 4:
                        viewOwnerHall();
                        break;

                        case 5:
                        createDiscount();
                        break;

                        case 6:
                        deleteDiscount("ownerdiscount.txt", "Owner");
                        break;

                        case 7:
                        System.out.println("There is no discount list!");
                        break;

                        case 8:
                        readDiscountFile("ownerdiscount.txt","Owner");
                        break;

                        case 9:
                        System.out.println("There is no payment list!");
                        break;

                        case 10:
                        System.out.println("There is no quotation available!");
                        break;

                        case 11:
                        System.out.println("There is no review list");
                        break;

                        case 12:
                        option = 0;
                        break;

                        case 13:
                        System.exit(0);
                        break;
                    }
                    break;
                }

                case 4:        
                registerMenu();
                int userOption = input.acceptIntegerInput("");
                if(userOption == 1)
                {
                    ownerRegister();
                }
                if(userOption == 2)
                {   
                    customerRegister();              
                }
                break;

                case 5:       
                System.exit(0);
            }
        }
    }            

    public void menu()
    {
        System.out.println("=====================================");
        System.out.println("Welcome to Prime Event System");
        System.out.println("=====================================");
        System.out.println("1----Admin");
        System.out.println("2----Customer");
        System.out.println("3----Owner");
        System.out.println("4----Register");
        System.out.println("5----Exit");
        System.out.println("Please select an option:");   
    }

    public void adminMenu()
    {
        System.out.println("1--Create discount");
        System.out.println("2--Delete discount");
        System.out.println("3--Update discount");
        System.out.println("4--View discount");
        System.out.println("5--Reset users password");
        System.out.println("6--Manage reviews");
        System.out.println("7--View hall");
        System.out.println("8--View reviews");
        System.out.println("9--Logout"); 
        System.out.println("10--Quit"); 
        System.out.println("Please select an option from the menu:");
    }

    public void ownerMenu()
    {        
        System.out.println("1--Create hall");            
        System.out.println("2--Update hall");
        System.out.println("3--Delete hall");
        System.out.println("4--View hall"); 
        System.out.println("5--Create discount");
        System.out.println("6--Delete discount");
        System.out.println("7--Update discount"); 
        System.out.println("8--View discount"); 
        System.out.println("9--Manage payment");
        System.out.println("10--View quotation request");
        System.out.println("11--View review"); 
        System.out.println("12--Logout"); 
        System.out.println("13--Quit"); 
        System.out.println("Please select an option from the menu:");
    }

    public void customerMenu()
    {
        System.out.println("1--View hall");            
        System.out.println("2--Search hall");
        System.out.println("3--Request quotation");
        System.out.println("4--View quotation requested list");
        System.out.println("5--View discount"); 
        System.out.println("6--Manage Booking History");
        System.out.println("7--Write review on previous booking"); 
        System.out.println("8--View review"); 
        System.out.println("9--Logout"); 
        System.out.println("10--Quit"); 
        System.out.println("Please select an option from the menu:");
    }

    public void registerMenu()
    {
        System.out.println("1--Owner");
        System.out.println("2--Customer");
        System.out.println("Please select an option to register");
    }

    public boolean adminLogin()
    {
        Input input = new Input();
        FileIO fileio = new FileIO();
        boolean loginMatch = true;
        String read = fileio.readFile("adminlogin.txt");
        String[] lineArray = read.split(",");
        String adminId = lineArray[0];
        String password = lineArray[1];
        String userInputId = input.acceptInput("Please enter your email id:");
        String userInputPass = input.acceptInput("Please enter your password:");
        if(userInputId.equals(adminId))
        {
            if(userInputPass.equals(password))
            {
                System.out.println("login successful");
                loginMatch = true;
            }
        }
        else
        {
            System.out.println("login failed");
            loginMatch = false;
        }
        return loginMatch;
    }

    public void readHallFile()
    {
        String hallName;
        String hallAddress;
        String hallDescription;
        boolean hallAvailability;
        String typeOfEvent;
        int sizeOfHall;
        boolean cateringAvailability;
        boolean decorationAvailability;
        String contactDetail;
        String contactName;
        FileIO fileIO = new FileIO();

        ArrayList<String> readHall = fileIO.readFileArray("hall.txt");
        if(readHall.size() != 0)
        {
            StringBuffer line = new StringBuffer();
            for (String s : readHall)
            {
                line.append(s);
                line.append("///");
            }
            String [] hallList = line.toString().split("///");   
            for(int i = 0; i < hallList.length; i++)
            {
                String [] arrayFromHallFile = hallList[i].split(",");
                hallName = arrayFromHallFile[0];
                hallAddress = arrayFromHallFile[1];
                hallDescription = arrayFromHallFile[2];
                hallAvailability = Boolean.parseBoolean(arrayFromHallFile[3]);
                typeOfEvent = arrayFromHallFile[4];
                sizeOfHall = Integer.parseInt(arrayFromHallFile[5]);
                cateringAvailability = Boolean.parseBoolean(arrayFromHallFile[6]);
                decorationAvailability = Boolean.parseBoolean(arrayFromHallFile[7]);
                contactDetail = arrayFromHallFile[8];
                contactName = arrayFromHallFile[9];
                halls.addHalls(hallName, hallAddress, hallDescription, hallAvailability, typeOfEvent, sizeOfHall, cateringAvailability,decorationAvailability,contactDetail,contactName);                
                System.out.println(i+1 + ".");
                halls.getHall(i).displayHall();

            }
        }
        else
        {
            System.out.println("There is no hall available!");
        }

    }

    public boolean customerLogin()
    {
        Input input = new Input();
        FileIO fileio = new FileIO();
        boolean loginMatch = true;
        String customerId;
        String customerPass;

        try
        {
            Scanner fileScan = new Scanner(new File("customerlogin.txt"));
            if(fileScan.hasNextLine()) 
            {
                String scan = fileScan.nextLine();
                String[] lineArray = scan.split(",");
                customerId = lineArray[0];
                customerPass = lineArray[1];
                customers.addCustomers(customerId,customerPass,"","");
                String userInputId = input.acceptInput("Please enter your email id:");
                String userInputPass = input.acceptInput("Please enter your password:");
                if(userInputId.equals(customerId))
                {
                    if(userInputPass.equals(customerPass))
                    {
                        System.out.println("login successful");
                        loginMatch = true;
                    }
                }
                else
                {
                    System.out.println("login failed");
                    loginMatch = false;
                }
            }
            else
            {
                System.out.println("No data available please register");
                loginMatch = false;
            }
        }
        catch(Exception e)
        {
            System.out.println("File not exist!");
        }
        return loginMatch;
    }

    public boolean ownerLogin()
    {
        Input input = new Input();
        FileIO fileio = new FileIO();
        boolean loginMatch = true;
        String ownerId;
        String ownerPass;
        try
        {
            Scanner fileScan = new Scanner(new File("ownerlogin.txt"));
            if(fileScan.hasNextLine()) 
            {
                String scan = fileScan.nextLine();
                String[] lineArray = scan.split(",");
                ownerId = lineArray[0];
                ownerPass = lineArray[1];
                String userInputId = input.acceptInput("Please enter your email id:");
                String userInputPass = input.acceptInput("Please enter your password:");
                if(userInputId.equals(ownerId))
                {
                    if(userInputPass.equals(ownerPass))
                    {
                        System.out.println("login successful");
                        loginMatch = true;
                    }
                }
                else
                {
                    System.out.println("login failed");
                    loginMatch = false;
                }
            }
            else
            {
                System.out.println("No data available please register");
                loginMatch = false;
            }
        }
        catch(Exception e)
        {
            System.out.println("File not exist!");
        }
        return loginMatch;
    }

    public void customerRegister()
    {
        Input input = new Input();
        FileIO fileIO = new FileIO();
        boolean check = true;
        boolean check1 = true;
        Scanner console = new Scanner(System.in);
        String emailId = input.acceptInput("Please enter your email address to register as email id:");
        do
        {
            input.checkValidEmail(emailId);
            if(check==false)
            {
                System.out.println("Please enter a valid email id");
            }
        }while(check==false);
        String password = input.acceptInput("Please enter password:");
        do
        {
            input.checkLength(password,6,999999);
            if(check1==false)
            {
                System.out.println("Please enter at least 6 characters!");
            }
        }while(check1==false);
        String repass = input.acceptInput("Please re-enter password:");
        if(!repass.equals(password))
        {
            System.out.println("Password does not match! Please re-enter password!");
            console.nextLine();
            password = input.acceptInput("Please enter password:");
            repass = input.acceptInput("Please re-enter password:");
        }
        else
        {
            String contents = emailId + "," + repass;
            fileIO.writeFile(contents, "customerlogin.txt");
            System.out.println("Register successful");
        }

    }

    public void ownerRegister()
    {
        Input input = new Input();
        FileIO fileIO = new FileIO();
        boolean check = true;
        boolean check1 = true;
        Scanner console = new Scanner(System.in);
        String emailId = input.acceptInput("Please enter your email address to register as email id:");
        do
        {
            input.checkValidEmail(emailId);
            if(check==false)
            {
                System.out.println("Please enter a valid email id");
            }
        }while(check==false);
        String password = input.acceptInput("Please enter password:");
        do
        {
            input.checkLength(password,6,999999);
            if(check1==false)
            {
                System.out.println("Please enter at least 6 characters!");
            }
        }while(check1==false);
        String repass = input.acceptInput("Please re-enter password:");
        if(!repass.equals(password))
        {
            System.out.println("Password does not match! Please re-enter password!");
            console.nextLine();
            password = input.acceptInput("Please enter password:");
            repass = input.acceptInput("Please re-enter password:");
        }
        else
        {
            String contents = emailId + "," + repass;
            fileIO.writeFile(contents, "ownerlogin.txt");
            System.out.println("Register successful");
        }

    }

    public boolean readDiscountFile(String file,String user)
    {
        String discountName = "";
        String discountType = "";
        String description = "";        
        int discountMonth = 0;
        Scanner console = new Scanner(System.in);
        FileIO fileIO = new FileIO();
        ArrayList<String> readDiscount = fileIO.readFileArray(file);
        boolean check = true;
        if(readDiscount.size() != 0)
        {
            StringBuffer line = new StringBuffer();
            for (String s : readDiscount)
            {
                line.append(s);
                line.append("///");
            }
            String [] discountList = line.toString().split("///");   
            for(int i = 0; i < discountList.length; i++)
            {
                System.out.println(user + " discount:");
                String [] arrayFromDiscountFile = discountList[i].split(",");
                discountName = arrayFromDiscountFile[0];
                discountType = arrayFromDiscountFile[1];
                description = arrayFromDiscountFile[2];
                discountMonth = Integer.parseInt(arrayFromDiscountFile[3]);
                discounts.addDiscounts(discountName, discountType, description, discountMonth);
                System.out.println(i+1 + ".");
                discounts.getDiscount(i).displayDiscount();
                check = true;
            }
        }
        else
        {
            System.out.println("There is no discount available!");
            console.nextLine();
            check = false;
        }
        return check;
    }

    public void deleteDiscount(String file,String user)
    {
        FileIO fileIO = new FileIO();
        int userInput = 0;
        int index = 0;
        Input input = new Input();
        boolean check = true;
        readDiscountFile(file, user);

        do
        {           
            userInput = input.acceptIntegerInput("Please enter the number of the discount you wishes to delete:");
            index = userInput-1;
            check = input.checkRange(userInput,1,discounts.getNumberOfDiscounts());
            if(check == false)
            {
                System.out.println("Please select from 1 to " + discounts.getNumberOfDiscounts()+ " only!");
            }
        }while(check == false);

        String deleteItem = discounts.getDiscount(index).getDiscountName()+","+discounts.getDiscount(index).getDiscountType()
            +","+discounts.getDiscount(index).getDescription()+","+discounts.getDiscount(index).getDiscountMonth();                    
        discounts.getDiscount(index).setDiscountName("");
        discounts.getDiscount(index).setDiscountType("");
        discounts.getDiscount(index).setDescription("");
        discounts.getDiscount(index).setDiscountMonth(0);
        fileIO.removeSomethingFromFile(file,deleteItem);

    }
    public void searchHall()
    {
        Input input = new Input();
        int userInput = input.acceptIntegerInput("Please enter the size of hall you wishes to search: ");
        int count = 0;
        for (int i = 0 ; i < halls.getNumberOfHalls() ; i++)
        {           
            if(halls.getHall(i).getSizeOfHall() == userInput)
            {
                halls.getHall(i).displayHall();
                count ++;
            }        
        }   
        if(count == 0)
        {
            System.out.println("No matched hall size!");
        }
    }

    public void updateHall()
    {
        Input input = new Input();
        int option = 1;    
        boolean check = true;
        for (int i = 0 ; i < halls.getNumberOfHalls() ; i++)
        {           
            System.out.println(option);
            halls.getHall(i).displayHall();
            option++;           
        }
        int userInput = input.acceptIntegerInput("Please select the hall you want to modify: ");
        int index = userInput-1;
        halls.getHall(index).displayHall();
        System.out.println("1. Hall Name: ");
        System.out.println("2. Hall Description: ");
        System.out.println("3. Hall Availability: ");
        System.out.println("4. Hall Type Of Event: ");
        System.out.println("5. Hall Size: ");
        System.out.println("6. Hall Address: ");
        System.out.println("7. Catering Availability: ");
        System.out.println("8. Decoration Availability: ");
        System.out.println("9. Contact Detail: " );
        System.out.println("10. Contact Name");
        int userInput1 = input.acceptIntegerInput("Please select options that you wish to change:");
        if(userInput1 == 1)
        {
            System.out.println(halls.getHall(index).getHallName());
            String reset = input.acceptInput("Please re-name your hall: ");
            halls.getHall(index).setHallName(reset);
            System.out.println(halls.getHall(index).displayHall());
        }
        if(userInput1 == 2)
        {
            System.out.println(halls.getHall(index).getHallDescription());
            String reset = input.acceptInput("Please re-enter your hall description: ");
            halls.getHall(index).setHallDescription(reset);
            System.out.println(halls.getHall(index).displayHall());            
        }
        if(userInput1 == 3)
        {     
            do
            {  
                System.out.println(halls.getHall(index).getHallAvailability());
                String reset = input.acceptInput("Please re-enter your hall availability: ");
                check = input.checkBoolean(reset);
                if(check == false)
                {
                    System.out.println("Please enter true or false only!");
                }
                else
                {
                    boolean in = Boolean.parseBoolean(reset);
                    halls.getHall(index).setHallAvailability(in);
                    System.out.println(halls.getHall(index).displayHall());
                }
            }while(check == false);
        }
        if(userInput1 == 4)
        {
            do
            {
                System.out.println(halls.getHall(index).getTypeOfEvent());
                System.out.println("1. Wedding Ceremony");      
                System.out.println("2. Wedding Reception");  
                System.out.println("3. Birthday"); 
                System.out.println("4. Anniversary");  
                int reset = input.acceptIntegerInput("Please select the option: ");
                check = input.checkRange(reset,1,4);
                if(check == false)
                {
                    System.out.println("Please enter 1-4 only!");
                }
                else
                {
                    if(reset == 1)
                    {
                        halls.getHall(index).setTypeOfEvent("Wedding Ceremony");
                        System.out.println(halls.getHall(index).displayHall());
                    }
                    if(reset == 2)
                    {
                        halls.getHall(index).setTypeOfEvent("Wedding Reception");
                        System.out.println(halls.getHall(index).displayHall());
                    }
                    if(reset == 3)
                    {
                        halls.getHall(index).setTypeOfEvent("Birthday");
                        System.out.println(halls.getHall(index).displayHall());
                    }
                    if(reset == 4)
                    {
                        halls.getHall(index).setTypeOfEvent("Anniversary");
                        System.out.println(halls.getHall(index).displayHall());
                    }
                }
            }while(check == false);
        }
        if(userInput1 == 5)
        {
            do
            {
                System.out.println(halls.getHall(index).getSizeOfHall());               
                int reset = input.acceptIntegerInput("Please input the new hall size: ");
                check = input.checkRange(reset,0,99999999);
                if(check == false)
                {
                    System.out.println("Please enter number greater than 0 only!");
                }
                else
                {
                    halls.getHall(index).setSizeOfHall(reset);
                    System.out.println(halls.getHall(index).displayHall());
                }
            }while(check == false);
        }
        if(userInput1 == 6)
        {
            System.out.println(halls.getHall(index).getHallAddress());
            String reset = input.acceptInput("Please re-name your hall address: ");
            halls.getHall(index).setHallAddress(reset);
            System.out.println(halls.getHall(index).displayHall());
        }
        if(userInput1 == 7)
        {
            do
            {  
                System.out.println(halls.getHall(index).getCateringAvailability());
                String reset = input.acceptInput("Please re-enter your catering availability: ");
                check = input.checkBoolean(reset);
                if(check == false)
                {
                    System.out.println("Please enter true or false only!");
                }
                else
                {
                    boolean in = Boolean.parseBoolean(reset);
                    halls.getHall(index).setCateringAvailability(in);
                    System.out.println(halls.getHall(index).displayHall());
                }
            }while(check == false);
        }
        if(userInput1 == 8)
        {
            System.out.println(halls.getHall(index).getContactDetail());
            String reset = input.acceptInput("Please input new contact detail: ");
            halls.getHall(index).setContactDetail(reset);
            System.out.println(halls.getHall(index).displayHall());
        }
        if(userInput1 == 9)
        {
            System.out.println(halls.getHall(index).getContactName());
            String reset = input.acceptInput("Please input new contact name: ");
            halls.getHall(index).setContactName(reset);
            System.out.println(halls.getHall(index).displayHall());
        }
        if(option == 0)
        {
            System.out.println("There is no hall available!");
        }
    }

    public void deleteHall()
    {
        FileIO fileIO = new FileIO();
        int userInput = 0;
        int index = 0;
        Input input = new Input();
        boolean check = true;
        for(int i = 0; i < halls.getNumberOfHalls(); i++)
        {
            System.out.println(index+1);
            halls.getHall(index).displayHall();
        }
        do
        {      
            userInput = input.acceptIntegerInput("Please enter the number of the hall you wishes to delete:");
            index = userInput-1;
            check = input.checkRange(userInput,1,halls.getNumberOfHalls());
            if(check == false)
            {
                System.out.println("Please select from 1 to " + halls.getNumberOfHalls()+ " only!");
            }
        }while(check == false);
        String deleteItem = halls.getHall(index).getHallName()+","+
            halls.getHall(index).getHallAddress()+","+
            halls.getHall(index).getHallDescription()+","+
            halls.getHall(index).getHallAvailability()+","+
            halls.getHall(index).getTypeOfEvent()+","+
            halls.getHall(index).getSizeOfHall()+","+
            halls.getHall(index).getCateringAvailability()+","+
            halls.getHall(index).getDecorationAvailability()+","+
            halls.getHall(index).getContactDetail()+","+
            halls.getHall(index).getContactName(); 

        halls.getHall(index).setHallName("");
        halls.getHall(index).setHallAddress("");
        halls.getHall(index).setHallDescription("");
        halls.getHall(index).setHallAvailability(true);
        halls.getHall(index).setTypeOfEvent("");
        halls.getHall(index).setSizeOfHall(0);
        halls.getHall(index).setCateringAvailability(true);
        halls.getHall(index).setDecorationAvailability(true);
        halls.getHall(index).setContactDetail("");
        halls.getHall(index).setContactName(""); 
        fileIO.removeSomethingFromFile("hall.txt","owner");
    }

    public void viewOwnerHall()
    {
        Input input = new Input();
        String name = input.acceptInput("Please enter contact name that is set in hall");
        for(int i = 0 ; i < halls.getNumberOfHalls() ; i++)
        {
            if(name.equals(halls.getHall(i).getContactName()))
            {
                halls.getHall(i).displayHall();
            }
        }
    }

    public void createDiscount()
    {
        Input input = new Input();
        String discoutName = "";
        String discountType = "";
        String description = "";
        int discountMonth = 0;
        boolean check = true;
        boolean checkDiscName = true;
        do
        {
             discountName = input.acceptInput("Please enter discount name:");
            checkDiscName = Pattern.matches("^[a-zA-Z]{3,10}$",discountName);
            if (discountName != null && !discountName.isEmpty())
            {
                if(!checkDiscName)
                {
                    System.out.println("Please enter discount name between 3 and  10 characters only!");
                }
            }
            else
            {
                System.out.println("Discount name should not be empty!");
            }
        }
        while(checkDiscName!=true);
        boolean checkDiscType = true;
        do
        {
            String discountType = input.acceptInput("Please enter type of discount:");
            checkDiscType = Pattern.matches("^[a-zA-Z]{3,10}$",discountType);
            if (discountType != null && !discountType.isEmpty())
            {
                if(!checkDiscType)
                {
                    System.out.println("Please enter type of discount between 3 and  10 characters only!");
                }
            }
            else
            {
                System.out.println("Discount type should not be empty!");
            }
        }
        while(checkDiscType!=true);
        boolean checkDiscDesc = true;
        do
        {
            String description = input.acceptInput("Please enter discount description:");
            checkDiscDesc = Pattern.matches("^[a-zA-Z]{5,20}$",description);
            if (description != null && !description.isEmpty())
            {
                if(!checkDiscDesc)
                {
                    System.out.println("Please enter discount description between 5 and  20 characters only!");
                }
            }
            else
            {
                System.out.println("Discount description should not be empty!");
            }
        }
        while(checkDiscDesc!=true);        
        do
        {
            int discountMonth = input.acceptIntegerInput("Please the length in month for the discount: ");
            input.checkRange(discountMonth,1,99999999);
            if(check==false)
            {
                System.out.println("Please enter the month greater than 1!");
            }
        }while(check==false);
        discounts.addDiscounts(discountName,discountType,description,discountMonth);
        System.out.println("Discount successfully created!");
    }

    public void requestQuotation()
    {
        Input input = new Input();  
        boolean check = true;        
        int userInputEvent;
        int userInputSize;
        String catering;
        String decoration;
        int userInputBudget; 
        boolean incatering=true;
        boolean indecoration=true;
        int userInputGuest;
        String event="";
        int inputOption = 0;

        readHallFile();
        if(halls.getNumberOfHalls()==0)
        {
            System.out.println("There is no hall available!");
        }
        else
        {
            do
            {
                inputOption= input.acceptIntegerInput("Please select the hall you want to request quotation:");
                check = input.checkRange(inputOption,1,halls.getNumberOfHalls());
                if(check==false)
                {
                    System.out.println("Please enter the size from 1-" +halls.getNumberOfHalls()+ " only!");
                }
            }while(check==false);  
        }

        if(halls.getNumberOfHalls()>0)
        {
            System.out.println("1. Wedding Ceremony");      
            System.out.println("2. Wedding Reception");  
            System.out.println("3. Birthday"); 
            System.out.println("4. Anniversary");  
            do
            {
                userInputEvent = input.acceptIntegerInput("Please enter the event use for this hall:");
                check = input.checkRange(userInputEvent,1,4);
                if(check==false)
                {
                    System.out.println("Please enter 1-4 only!");
                }
                if(userInputEvent == 1)
                {
                    event = "Wedding Ceremony";    
                }
                if(userInputEvent == 2)
                {
                    event = "Wedding Reception";
                }
                if(userInputEvent == 3)
                {
                    event ="Birthday";
                }
                if(userInputEvent == 4)
                {
                    event ="Anniversary";
                }
            }while(check==false);        
            do
            {
                userInputSize = input.acceptIntegerInput("Please enter the size of hall that will be used:");
                check = input.checkRange(userInputSize,1,99999999);
                if(check==false)
                {
                    System.out.println("Please enter the size greater than 1!");
                }
            }while(check==false);        
            do
            {                  
                catering = input.acceptInput("Please enter if you want catering availability: true/false ");
                check = input.checkBoolean(catering);
                if(check == false)
                {
                    System.out.println("Please enter true or false only!");
                }
                else
                {
                    incatering = Boolean.parseBoolean(catering);                
                }
            }while(check == false);
            do
            {                  
                decoration = input.acceptInput("Please enter if you want decoration availability: true/false ");
                check = input.checkBoolean(decoration);
                if(check == false)
                {
                    System.out.println("Please enter true or false only!");
                }
                else
                {
                    indecoration = Boolean.parseBoolean(decoration);                
                }
            }while(check == false);
            do
            {
                userInputBudget = input.acceptIntegerInput("Please enter the your budget:");
                check = input.checkRange(userInputBudget,1,99999999);
                if(check==false)
                {
                    System.out.println("Please enter the size greater than 1!");
                }
            }while(check==false);    
            do
            {
                userInputGuest = input.acceptIntegerInput("Please enter the estimated guest:");
                check = input.checkRange(userInputBudget,1,99999999);
                if(check==false)
                {
                    System.out.println("Please enter the size greater than 1!");
                }
            }while(check==false);   
            quotations.addQuotations(event,userInputSize,incatering,indecoration,userInputBudget,userInputGuest);
        }        
    }
    public void quotationList()
    {
        int userInput=0;
        boolean check = true;
        Input input = new Input();
        for(int i=0 ; i<quotations.getNumberOfQuotations(); i++)
        {
            System.out.println(i+1);
            quotations.getQuotation(i).displayQuotation();
        }
        if(quotations.getNumberOfQuotations()==0)
        {
            System.out.println("No Accepted Quotation list available.");
        }
        if(quotations.getNumberOfQuotations()>0)
        {
            while(userInput !=100)
            {
                do
                {
                    userInput = input.acceptIntegerInput("Please enter the accepted quotation to book hall or press 100 to back to menu:");
                    check = input.checkRange(userInput,1,quotations.getNumberOfQuotations());
                    if(check==false)
                    {
                        System.out.println("Please enter from 1-" + quotations.getNumberOfQuotations()+ " only!");
                    }
                }while(check==false);  
            }
        }
    }

    public void createHall()
    {
        Input input = new Input();
        boolean checkName = true;
        do
        {
            String hallName = input.acceptInput("Please enter hall name:");
            checkName = Pattern.matches("^[a-zA-Z]{3,10}$",hallName);
            if (hallName != null && !hallName.isEmpty())
            {
                if(!checkName)
                {
                    System.out.println("Please enter hall name between 3 and  10 characters only!");
                }
            }
            else
            {
                System.out.println("Hall name should not be empty!");
            }
        }
        while(checkName!=true);
        boolean checkLocation = true;
        do
        {
            String hallLocation = input.acceptInput("Please enter hall location");
            checkLocation = Pattern.matches("^[a-zA-Z]{4,10}$",hallLocation);
            if (hallLocation != null && !hallLocation.isEmpty())
            {
                if(!checkLocation)
                {
                    System.out.println("Please enter hall location between 4 and 10 characters only!");      
                }
            }
            else
            {
                System.out.println("Hall location should not be empty!");
            }
        }while(checkLocation!=true);
        boolean checkDescription = true;
        do
        {
            String hallDescription = input.acceptInput("Please enter hall decsription");
            checkDescription = Pattern.matches("^[a-zA-Z]{10,50}$",hallDescription);
            if (hallDescription != null && !hallDescription.isEmpty())
            {
                if(!checkDescription)
                {
                    System.out.println("Please enter hall description between 10 and 50 characters only!");      
                }
            }
            else
            {
                System.out.println("Hall description should not be empty!");
            }
        }while(checkDescription!=true);
        boolean checkConName = true;
        do
        {
            String contactName = input.acceptInput("Please enter contact name:");
            checkConName = Pattern.matches("^[a-zA-Z]{2,10}$",contactName);
            if (contactName != null && !contactName.isEmpty())
            {
                if(!checkConName)
                {
                    System.out.println("Please enter contact name between 2 and 10 characters only!");      
                }
            }
            else
            {
                System.out.println("Contact name should not be empty!");
            }
        }while(checkConName!=true);
        boolean checkConNo = true;
        do
        {
            String contactNumber = input.acceptInput("Please enter contact number:");
            checkConNo = Pattern.matches("\\d{10}",contactNumber);
            if (contactNumber != null && !contactNumber.isEmpty())
            {
                if(!checkConNo)
                {
                    System.out.println("Please enter contact number of 10 digits only!");      
                }
            }
            else
            {
                System.out.println("Contact number should not be empty!");
            }
        }while(checkConNo!=true);                   
        boolean checkEventType = true;   
        do
        {
        int userInputEvent;
        String catering;
        String event="";
        int inputOption = 0;
        System.out.println("============Options For Type of Events==========");        
        System.out.println("1. Wedding Ceremony");      
        System.out.println("2. Wedding Reception");  
        System.out.println("3. Birthday"); 
        System.out.println("4. Anniversary");
        userInputEvent = input.acceptIntegerInput("Please select one option for type of event for this hall:");
        checkEventType = input.checkRange(userInputEvent,1,4);
        if(checkEventType==false)
        {
         System.out.println("Please enter 1-4 only!");
        }
        if(userInputEvent == 1)
        {
        event = "Wedding Ceremony";    
        }
        if(userInputEvent == 2)
        {
        event = "Wedding Reception";
        }
        if(userInputEvent == 3)
        {
        event ="Birthday";
        }
        if(userInputEvent == 4)
        {
        event ="Anniversary";
        }
        }while(checkEventType==false);   
        boolean checkPrice = true;
        int hallPrice = input.acceptIntegerInput("Please enter the price of hall:");
        do
        {            
          input.checkRange(hallPrice,1,99999999);
          if(checkPrice==false)
          {
           System.out.println("Please enter valid number from 1-9 only");
          }
        }while(checkPrice==false);
        String check;        
        boolean checkFlag=false;
        do
        {                  
            check = input.acceptInput("Please enter catering availability for this hall: Yes/No");            
            if(check.equalsIgnoreCase("yes") || check.equalsIgnoreCase("no"))
            {
                checkFlag = true;
            }
            else
            {
                System.out.println("Please enter Yes or No only!");               
            }
        }while(!checkFlag);
        String check1;        
        boolean check1Flag=false;
        do
        {                  
            check1 = input.acceptInput("Please enter decoration availability for this hall: Yes/No");            
            if(check1.equalsIgnoreCase("yes") || check1.equalsIgnoreCase("no"))
            {
                check1Flag = true;
            }
            else
            {
                System.out.println("Please enter Yes or No only!");               
            }
        }while(!check1Flag);
        String check2;        
        boolean check2Flag=false;
        do
        {                  
            check2 = input.acceptInput("Please enter hall availability for this hall: Yes/No");            
            if(check2.equalsIgnoreCase("yes") || check2.equalsIgnoreCase("no"))
            {
                check1Flag = true;
            }
            else
            {
                System.out.println("Please enter Yes or No only!");               
            }
        }while(!check2Flag);
}}
