
public class Administrator
{    
    private String adminName;
    private String passwd;
    private String emailAddress;
    private String phoneNumber;
    private String address;
    
    public Administrator()
    {
        adminName = "";
        passwd = "";
        emailAddress = "";
        phoneNumber = "";
        address = "";
    }
    public Administrator(String newAdminName,String newPasswd, String newEmail, String newPhoneNumber, String newAddress)
    {
        adminName = newAdminName;
        passwd = newPasswd;
        emailAddress = newEmail;
        phoneNumber = newPhoneNumber;
        address = newAddress;
    }
    public void setName(String newAdminName)
    {
        adminName= newAdminName;
    }
    public String getAdminName()
    {
        return adminName;
    }
    public void setPasswd(String newPasswd)
    {
        passwd = newPasswd;
    }
    public String getPasswd()
    {
        return passwd;
    }
    public void setEmailAddress(String newEmail)
    {
        emailAddress = newEmail;
    }
    public String getEmailAddress()
    {
        return emailAddress;
    }
    public void setPhoneNumber(String newPhoneNumber)
    {
        phoneNumber = newPhoneNumber;
    }
    public String phoneNumber()
    {
        return phoneNumber;
    }
    public void setAddress(String newAddress)
    {
        address = newAddress;
    }
    public String getAddress()
    {
        return address;
    }
    public String displayAdmin()
    {
        System.out.println("Administrator name: " + adminName);
        System.out.println("Password: " + passwd);
        System.out.println("Email Address: " + emailAddress);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Address: " + address);
        return ("Administrator name: " + adminName + "Password: " + passwd + "Email Address: " + emailAddress +
                "Phone Number: " + phoneNumber + "Address: " + address);
    }
    public String toString()
    {
        return ("Administrator name: " + adminName + "Password: " + passwd + "Email Address: " + emailAddress +
                "Phone Number: " + phoneNumber + "Address: " + address);
    }
}