import java.util.*;
import java.io.*;

public class ListOfOwners
{
    private ArrayList<Owner> owners;
    public ListOfOwners()
    {
        this.owners = new ArrayList<Owner>();
    }
    public ListOfOwners(ArrayList<Owner> newOwner)
    {
        this.owners = newOwner;
    }
    public void setOwners(ArrayList<Owner> newOwner)
    {
        this.owners = newOwner;
    }
    public ArrayList<Owner> getOwners()
    {
        return owners;
    }
    public void addOwners(String newName,String newPasswd, String newEmail, String newPhoneNumber, String newAddress)
    {
        Owner newOwner = new Owner(newName, newPasswd, newEmail, newPhoneNumber, newAddress);
        owners.add(newOwner);
    }
        
    public int getNumberOfOwners()
    {
        return owners.size();
    }
    
    public void listAllOwners()
    {
        for(int i = 0;  i < owners.size(); i++)
        {
            System.out.println(owners.get(i));
        }
    }
    
    public Owner getOwner(int index)
    {
        return owners.get(index);
    }
    
}
