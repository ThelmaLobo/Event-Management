

public class DepositPayment
{
    private int depositAmount;
    
    public DepositPayment()
    {
        depositAmount = 0;
    }
    public DepositPayment(int newDepositAmount)
    {
        depositAmount = newDepositAmount;
    }
    public void setAmount(int newDepositAmount)
    {
        depositAmount = newDepositAmount;
    }
    public int getAmount()
    {
        return depositAmount;
    }
    public String displayDeposit()
    {
        System.out.println("Deposit Amount: " + depositAmount);
        return ("Deposit Amount: " + depositAmount);
    }
    public String toString()
    {
        return ("Deposit Amount: " + depositAmount);
    }




}
