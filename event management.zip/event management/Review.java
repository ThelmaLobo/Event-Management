
public class Review
{
    private String reviewDescription;
    private int reviewRating;


    public Review()
    {
        reviewDescription = "";
        reviewRating = 0;
    }
    public Review(String newReviewDescription,int newReviewRating)
    {
        reviewDescription = newReviewDescription;
        reviewRating = newReviewRating;
    }
    public void setReviewDescription(String newReviewDescription)
    {
        reviewDescription = newReviewDescription;
    }
    public String getReviewDescription()
    {
        return reviewDescription;
    }
    public void setReviewRate(int newReviewRating)
    {
        reviewRating = newReviewRating;
    }
    public int getReviewRate()
    {
        return reviewRating;
    }
    public String displayReview()
    {
        System.out.println("Review Description: " + reviewDescription);
        System.out.println("Review Rating: " + reviewRating);
        return ("Review Description: " + reviewDescription +"Review Rating: " + reviewRating);
    }
    public String toString()
    {
        return ("Review Description: " + reviewDescription +"Review Rating: " + reviewRating);
    }
    



}
