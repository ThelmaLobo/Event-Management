import java.util.*;

public class Input
{
  

    /**
     * Constructor for objects of class Input
     */
    public Input()
    {
    
    }

    public String acceptInput(String displayMessage)
    {
        Scanner input = new Scanner(System.in);
        System.out.println(displayMessage);
        String userInput = "";
        try
        {
            userInput = input.nextLine();
        }
        catch(Exception e)
        {
            System.out.println("Please enter String only!");
        }
        return userInput;
    }
    
    public String acceptInput()
    {
        Scanner input = new Scanner(System.in);
        String userInput = "";
        try
        {
            userInput = input.nextLine();
        }
        catch(Exception e)
        {
            System.out.println("Please enter String only!");
        }
        return userInput;
    }
    
    public int acceptIntegerInput(String displayMessage)
    {
        Scanner input = new Scanner(System.in);
        System.out.println(displayMessage);
        int userInput = 0;
        try
        {
            userInput = input.nextInt();
        }
        catch(Exception e)
        {
            System.out.println("Please enter integer only!");
        }
        return userInput;    
    }
    
    public int acceptIntegerInput()
    {
        Scanner input = new Scanner(System.in);
        int userInput = 0;
        try
        {
            userInput = input.nextInt();
        }
        catch(Exception e)
        {
            System.out.println("Please enter integer only!");
        }
        return userInput;    
    }
    
    public boolean checkBoolean(String word)
    {
        
        if(word.toLowerCase().trim().equals("true"))
        {
            return true;
        }
        else if(word.toLowerCase().trim().equals("false"))
        {
            return true;
        }
        else
        {
            return false;
        }
        
    }
    public boolean checkRange(int number, int min, int max)
    {
        boolean check;
        if(number >= min && number <= max )
        {
            return true;
        }        
        else
        {
            return false;
        }

    }
    
    public boolean checkValidEmail(String email)
    {
        String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
        java.util.regex.Matcher m = p.matcher(email);
        return m.matches();
    }
    
    public boolean checkLength(String word,int min,int max)
    {
        boolean check;
        if(word.length() >= min || word.length() <= max )
        {
            return true;
        }        
        else
        {
            return false;
        }
    }
}
