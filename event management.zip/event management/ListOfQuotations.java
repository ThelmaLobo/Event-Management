import java.util.*;
import java.io.*;

public class ListOfQuotations
{
    private ArrayList<Quotation> quotations;
      
    public ListOfQuotations()
    {
        this.quotations = new ArrayList<Quotation>();
    }
    public ListOfQuotations(ArrayList<Quotation> newQuotation)
    {
        this.quotations = newQuotation;
    }
    
    public void setQuotations(ArrayList<Quotation> newQuotation)
    {
        this.quotations = newQuotation;
    }
    
    /**
     * Return arraylist
     */
    public ArrayList<Quotation> getQuotations()
    {
        return quotations;
    }
    
    public void addQuotations(String newQuoteTypeOfEvent,int newQuoteSizeOfHall, boolean newQuoteCateringAvailability,
                       boolean newQuoteDecorationAvailability,int newQuoteTotalBudget, int newQuoteEstimatedGuest)
    {
        Quotation newQuotation = new Quotation(newQuoteTypeOfEvent,newQuoteSizeOfHall,newQuoteCateringAvailability,
                      newQuoteDecorationAvailability,newQuoteTotalBudget,
                       newQuoteEstimatedGuest);
        quotations.add(newQuotation);
    }
        
    public int getNumberOfQuotations()
    {
        return quotations.size();
    }
    
    public void listAllQuotations()
    {
        for(int i = 0;  i < quotations.size(); i++)
        {
            System.out.println(quotations.get(i));
        }
    }
    
    public Quotation getQuotation(int index)
    {
        return quotations.get(index);
    }
}
